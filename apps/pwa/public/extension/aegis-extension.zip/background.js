const t = typeof chrome < "u" && !!chrome.storage;
async function e() {
  if (t)
    try {
      await chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_AND_UNTRUSTED_CONTEXTS" });
    } catch {
    }
}
chrome.runtime.onInstalled.addListener(() => void e());
chrome.runtime.onStartup.addListener(() => void e());
