(function(){"use strict";var w,y;const E={google:{color:"linear-gradient(145deg,#4285F4,#1a56c4)",initial:"G"},github:{color:"linear-gradient(145deg,#3a3f47,#16181d)",initial:"Gh"},nubank:{color:"linear-gradient(145deg,#a05fe6,#7211a8)",initial:"Nu"},figma:{color:"linear-gradient(145deg,#f24e1e,#c43410)",initial:"Fi"},netflix:{color:"linear-gradient(145deg,#e50914,#8a0009)",initial:"N"},spotify:{color:"linear-gradient(145deg,#1db954,#0a7d38)",initial:"Sp"},amazon:{color:"linear-gradient(145deg,#ff9900,#c46f00)",initial:"Az"},instagram:{color:"linear-gradient(145deg,#e1306c,#833ab4)",initial:"Ig"},binance:{color:"linear-gradient(145deg,#f0b90b,#a37c00)",initial:"Bn"},acme:{color:"linear-gradient(145deg,#2563eb,#1e40af)",initial:"A"}},g=["linear-gradient(145deg,#a78bfa,#7c3aed)","linear-gradient(145deg,#4285F4,#1a56c4)","linear-gradient(145deg,#34d399,#0a9d6c)","linear-gradient(145deg,#f24e1e,#c43410)","linear-gradient(145deg,#e1306c,#833ab4)","linear-gradient(145deg,#f0b90b,#a37c00)","linear-gradient(145deg,#1db954,#0a7d38)","linear-gradient(145deg,#5e7be6,#2b3f9e)","linear-gradient(145deg,#fb7185,#be123c)","linear-gradient(145deg,#2563eb,#1e40af)"];function C(e){let t=2166136261;for(let n=0;n<e.length;n++)t^=e.charCodeAt(n),t=Math.imul(t,16777619)>>>0;return t}function L(e){const t=e.trim().split(/\s+/).filter(Boolean);if(t.length===0)return"?";if(t.length===1){const n=t[0];return n.length>1?n[0].toUpperCase()+n[1].toLowerCase():n[0].toUpperCase()}return t[0][0].toUpperCase()+t[1][0].toLowerCase()}function S(e,t){const n=E[e];return n||{color:g[C(t||e)%g.length],initial:L(t)}}const o="aegis-ext",u="aegis.vault";async function k(){var e;if(typeof chrome>"u"||!((e=chrome.storage)!=null&&e.session))return null;try{return(await chrome.storage.session.get(u))[u]??null}catch{return null}}const m='<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M12 3l6.5 2.8v4.8c0 4-2.7 7.3-6.5 8.6-3.8-1.3-6.5-4.6-6.5-8.6V5.8L12 3z" fill="#fff" fill-opacity=".2" stroke="#fff" stroke-width="1.8"/></svg>';function z(){var e;return((e=document.body)==null?void 0:e.dataset.aegisDemo)||location.hostname.replace(/^www\./,"")}function M(e,t){if(!t)return[];const n=t.toLowerCase();return e.filter(i=>{const a=i.domain.toLowerCase();return a===n||a.endsWith(`.${n}`)||n.endsWith(`.${a}`)||a.split(".").slice(-2).join(".")===n})}function l(){const e=document.querySelector('input[type="password"]');if(!e)return null;const t=e.closest("form")??document,n=t.querySelector('input[type="email"]')??t.querySelector('input[type="text"][name*="user" i], input[type="text"][name*="email" i], input[type="text"][autocomplete="username"], input[type="text"]');return n?{user:n,pass:e}:null}function c(e,t){var i;const n=(i=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value"))==null?void 0:i.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function h(){if(document.getElementById(`${o}-styles`))return;const e=document.createElement("style");e.id=`${o}-styles`,e.textContent=`
@keyframes ${o}-toast {
  0% { transform: translate(-50%, 14px); opacity: 0; }
  12% { transform: translate(-50%, 0); opacity: 1; }
  88% { transform: translate(-50%, 0); opacity: 1; }
  100% { transform: translate(-50%, -6px); opacity: 0; }
}
.${o}-dropdown {
  position: absolute; z-index: 2147483646;
  background: #14141c; border-radius: 14px; padding: 6px;
  box-shadow: 0 18px 44px rgba(20,10,50,.34);
  border: 1px solid rgba(167,139,250,.25);
  font-family: 'Manrope', system-ui, sans-serif;
  box-sizing: border-box;
}
.${o}-dropdown * { box-sizing: border-box; }
.${o}-head {
  display: flex; align-items: center; gap: 7px; padding: 7px 9px 8px;
}
.${o}-head-logo {
  width: 20px; height: 20px; border-radius: 6px;
  background: linear-gradient(145deg,#a78bfa,#7c3aed);
  display: flex; align-items: center; justify-content: center;
}
.${o}-head-label {
  font-size: 11px; font-weight: 700; color: #a78bfa; letter-spacing: .3px;
}
.${o}-row {
  display: flex; align-items: center; gap: 11px; padding: 10px;
  border-radius: 10px; cursor: pointer; background: rgba(167,139,250,.1);
  border: none; width: 100%; text-align: left; margin-top: 2px;
}
.${o}-avatar {
  width: 36px; height: 36px; border-radius: 10px; flex: 0 0 auto;
  display: flex; align-items: center; justify-content: center;
  color: #fff; font-weight: 700; font-family: 'Sora', sans-serif;
}
.${o}-name { font-size: 13.5px; font-weight: 700; color: #f2f2f6; }
.${o}-user { font-size: 12px; color: #8b8b9c; }
.${o}-fill {
  padding: 7px 12px; border-radius: 8px;
  background: linear-gradient(145deg,#a78bfa,#7c3aed);
  color: #fff; font-size: 12px; font-weight: 700; flex: 0 0 auto;
}
.${o}-badge {
  position: absolute; z-index: 2147483646;
  width: 22px; height: 22px; border-radius: 6px;
  background: linear-gradient(145deg,#a78bfa,#7c3aed);
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 2px 8px rgba(124,58,237,.4); pointer-events: none;
}
.${o}-toast {
  position: fixed; bottom: 34px; left: 50%; z-index: 2147483647;
  animation: ${o}-toast 1.6s ease forwards;
  display: flex; align-items: center; gap: 9px; padding: 11px 18px;
  border-radius: 999px; background: #1c1c28;
  border: 1px solid rgba(255,255,255,.12);
  box-shadow: 0 12px 30px rgba(0,0,0,.5); white-space: nowrap;
  font-family: 'Manrope', system-ui, sans-serif;
  font-size: 14px; font-weight: 600; color: #f2f2f6;
}
`,document.head.appendChild(e)}function x(e){var n;(n=document.querySelector(`.${o}-toast`))==null||n.remove();const t=document.createElement("div");t.className=`${o}-toast`,t.innerHTML='<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg><span></span>',t.querySelector("span").textContent=e,document.body.appendChild(t),setTimeout(()=>t.remove(),1600)}function d(){var e;(e=document.getElementById(`${o}-dropdown`))==null||e.remove()}function T(e){const t=l();t&&(c(t.user,e.username),c(t.pass,e.password),d(),x("Preenchido pela Aegis"))}function A(e){const{color:t,initial:n}=S(e.id,e.name);return{background:t,initial:n}}function b(e,t,n){d();const i=e.getBoundingClientRect(),a=document.createElement("div");a.id=`${o}-dropdown`,a.className=`${o}-dropdown`,a.style.top=`${i.bottom+window.scrollY+7}px`,a.style.left=`${i.left+window.scrollX}px`,a.style.width=`${Math.max(i.width,280)}px`;const p=document.createElement("div");p.className=`${o}-head`,p.innerHTML=`<div class="${o}-head-logo">${m}</div><span class="${o}-head-label"></span>`,p.querySelector("span").textContent=`AEGIS · ${t.length} conta${t.length>1?"s":""} para ${n}`,a.appendChild(p);for(const s of t){const{background:q,initial:I}=A(s),r=document.createElement("button");r.type="button",r.className=`${o}-row`,r.innerHTML=`
      <div class="${o}-avatar"></div>
      <div style="flex:1; min-width:0;">
        <div class="${o}-name"></div>
        <div class="${o}-user"></div>
      </div>
      <div class="${o}-fill">Preencher</div>`;const $=r.querySelector(`.${o}-avatar`);$.style.background=q,$.textContent=I,r.querySelector(`.${o}-name`).textContent=s.name,r.querySelector(`.${o}-user`).textContent=s.username,r.addEventListener("click",()=>T(s)),a.appendChild(r)}document.body.appendChild(a);const v=s=>{!a.contains(s.target)&&s.target!==e&&(d(),document.removeEventListener("mousedown",v))};document.addEventListener("mousedown",v)}function B(e){if(document.getElementById(`${o}-badge`))return;const t=document.createElement("div");t.id=`${o}-badge`,t.className=`${o}-badge`,t.innerHTML=m;const n=()=>{const i=e.getBoundingClientRect();t.style.top=`${i.top+window.scrollY+(i.height-22)/2}px`,t.style.left=`${i.right+window.scrollX-22-10}px`};n(),document.body.appendChild(t),window.addEventListener("resize",n),window.addEventListener("scroll",n,!0)}async function f(){const e=l();if(!e)return;const t=await k();if(!t)return;const n=z(),i=M(t.credentials,n);i.length!==0&&(h(),B(e.pass),b(e.user,i,n),e.user.addEventListener("focus",()=>b(e.user,i,n)))}typeof chrome<"u"&&((w=chrome.storage)!=null&&w.onChanged)&&chrome.storage.onChanged.addListener((e,t)=>{t==="session"&&u in e&&(d(),f())}),typeof chrome<"u"&&((y=chrome.runtime)!=null&&y.id)&&chrome.runtime.onMessage.addListener((e,t,n)=>{const i=e;if((i==null?void 0:i.type)==="aegis-fill"&&i.username&&i.password){const a=l();a&&(h(),c(a.user,i.username),i.password&&c(a.pass,i.password),d(),x("Preenchido pela Aegis"));return}if((i==null?void 0:i.type)==="aegis-read-fields"){const a=l();n({username:(a==null?void 0:a.user.value)??""})}}),document.readyState==="loading"?document.addEventListener("DOMContentLoaded",f):f()})();
